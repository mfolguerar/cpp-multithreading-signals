#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include <time.h>

//Comunicacion Padre-Hijo. 0 para lectura  , 1 para escritura
int tuberia[2];
//La memoria compartida hacerla de 4 posiciones (3 para nivel 2 y 1 para el contador total de primos)
//para compartir entre el padre y los hijos de nivel 2
//Cada proecso de nivel 2 le envia mediante tuberia la posicion de memoria compartida para que el padre haga la suma y almacene
int shmid;
int *primos_cont;

int esPrimo(int num) {
    if (num <= 1) return 0;

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            return 0;
        }
    }
    return 1;
}

void procesarMatriz(int fila, int filas, int columnas, int matriz[filas][columnas]) {
    pid_t pid = getpid();
    char fileN3_nombre[20];
    sprintf(fileN3_nombre, "N3_%d.primos", pid);
    FILE *fileN3 = fopen(fileN3_nombre, "w");
    int contPrimos = 0;

    for (int j = 0; j < columnas; j++) {
        if (esPrimo(matriz[fila][j]) == 1) {
            contPrimos++;
            fprintf(fileN3, "3:%d:%d\n", pid, matriz[fila][j]);
        }
    }

    fclose(fileN3);
    exit(contPrimos);
}

void signalPadre(int senial) {
    char fileN1_nombre[20];
    sprintf(fileN1_nombre, "N1_%d.primos", getpid());
    FILE *fileN1 = fopen(fileN1_nombre, "a");
    fprintf(fileN1, "Soy el proceso padre y he recibido la señal: SIGUSR1\n");
    char mensaje[100];
    read(tuberia[0], mensaje, sizeof(mensaje));

    //obtener el numero de proceso y el numero del hijo
    int pidN2;
    int indice;
    sscanf(mensaje, "%d %d", &indice, &pidN2);
//memoria compartida contador total
    primos_cont[3] += primos_cont[indice];
    fprintf(fileN1, "Mensaje recibido: %s\n", mensaje);
    fclose(fileN1);

    // Enviar señal SIGINT para el pause()
    kill(pidN2, SIGINT);


}

void signalHijo(int senial) {
    exit(EXIT_SUCCESS);
}

int main() {
    int filas = 15;
    int columnas = 1000;
    int matriz[filas][columnas];

    srand(time(NULL));
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
            matriz[i][j] = rand() % 30000 + 1;
        }
    }
    //--------------Tuberia--------------
    if (pipe(tuberia) == -1) {
        perror("Error al crear la tubería");
        exit(EXIT_FAILURE);
    }
    //--------------Memoria Compartida--------------
    //1ºparametro :establecer directorio actual 
    //2ºparametro :clave de la memoria compartida
    key_t key = ftok("Practica2", 'K');
    //IPC_CREAT para crearlo si no existe , 0666 establece permisos R/W
    //memoria compartida de 4 posiciones 3 para los hijos nivel2 y una para contador total
    shmid = shmget(key, sizeof(int) * 4, IPC_CREAT | 0666);
    primos_cont = shmat(shmid, NULL, 0);
    primos_cont[3] = 0;

    //Crear señales para interrupcion nivel 1
    struct sigaction sigPadre;
    sigemptyset(&sigPadre.sa_mask);
    sigPadre.sa_flags = SA_RESTART;
    sigPadre.sa_handler = signalPadre;
    sigaction(SIGUSR1, &sigPadre, NULL);

    //---------------------------------Padre-------------------------------
    int pid_padre = getpid();
    char fileN1_nombre[20];
    sprintf(fileN1_nombre, "N1_%d.primos", pid_padre);
    FILE *fileN1 = fopen(fileN1_nombre, "a");
    fprintf(fileN1, "Comienzo\n");
    fclose(fileN1);

    for (int i = 0; i < 3; i++) {
        //Asignamos fila inicio=0 ,5 ,10 ...
        int filaInicio = i * 5;
        //Asignamos en grupos de 5 fila fin=0..4,5..9 
        int filaFin = filaInicio + 4;

    //---------------------------------Hijo (nivel 2)-------------------------------
        int pidN2 = fork();
        if (pidN2 < 0) {
            printf("Error al crear el hijo (nivel 2)\n");
            exit(0);
        } else if (pidN2 == 0) {
            //Crear señales para interrupcion nivel 2
            struct sigaction sigHijo;
            sigemptyset(&sigHijo.sa_mask);
            sigHijo.sa_flags = SA_RESTART;
            sigHijo.sa_handler = signalHijo;
            sigaction(SIGINT, &sigHijo, NULL);

            pid_t numpidN2 = getpid();
            char fileN2_nombre[20];
            sprintf(fileN2_nombre, "N2_%d.primos", numpidN2);
            FILE *fileN2 = fopen(fileN2_nombre, "a");
            fprintf(fileN2, "Inicio de ejecucion\n");
            fprintf(fileN2, "(nivel2)Proceso:%d, creo: 5 procesos nietos (nivel 3)\n", numpidN2);
            fclose(fileN2);
            int primos_contN2 = 0;

  //---------------------------------Nieto (nivel 3)-------------------------------
            //para 5 nietos
            for (int j = 0; j < 5; j++) {
                FILE *fileN2 = fopen(fileN2_nombre, "a");
                int pidN3 = fork();
                if (pidN3 < 0) {
                    printf("Error al crear el proceso nieto (nivel 3)\n");
                    exit(0);
                } else if (pidN3 == 0) {
                    //asignamos una fila a cada proceso
                    int fila = filaInicio + j;
                    pid_t numpidN3 = getpid();
                    fprintf(fileN2, "(nivel3)Proceso: %d\n", numpidN3);
                    fclose(fileN2);
                    procesarMatriz(fila, filas, columnas, matriz);
                    exit(0);
                }
            }
        //esperamos a que acaben todos los procesos nivel 3 y contamos
            for (int j = 0; j < 5; j++) {
                int status;
                wait(&status);
                if (WIFEXITED(status)) {
                    primos_contN2 += WEXITSTATUS(status);
                }
            }
            //actualizamos el contador del hijo nivel2 de memoria compartida
            primos_cont[i] = primos_contN2;

//enviamos mensaje al padre con el hijo en cuestion  de que ya esta completo el recuento 
            char mensaje[100];
            sprintf(mensaje, "%d %d", i, getpid());
            write(tuberia[1], mensaje, strlen(mensaje));
            // Enviamos señal SIGUSR1 al padre
            kill(pid_padre, SIGUSR1);
            pause();
        }

        FILE *fileN1 = fopen(fileN1_nombre, "a");
        fprintf(fileN1, "Soy el proceso: %d, padre (nivel 1) y he creado el proceso: %d, hijo (nivel 2)\n", pid_padre, pidN2);
        fclose(fileN1);
    }

    for (int i = 0; i < 3; i++) {
        wait(NULL);
    }

    fileN1 = fopen(fileN1_nombre, "a");
    printf("Total primos encontrados: %d\n", primos_cont[3]);
    fprintf(fileN1, "Total primos encontrados:%d\n", primos_cont[3]);
    fclose(fileN1);

    shmctl(shmid, IPC_RMID, NULL);
    return 0;
}
